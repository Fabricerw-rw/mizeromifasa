from flask import Flask, jsonify, request

app = Flask(__name__)

API_KEY = "mifasa_secret_key_123"

@app.route('/')
def home():
    return jsonify({"message": "Welcome to Mifasa API!", "status": "online"})

@app.route('/data', methods=['GET'])
def get_data():
    key = request.args.get('key')
    if key != API_KEY:
        return jsonify({"error": "Invalid API key"}), 403
    
    data = {
        "creator": "MIZERO FABRICE (MIFASA)",
        "project": "Mifasa API",
        "status": "success",
        "message": "Data fetched successfully!"
    }
    return jsonify(data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
